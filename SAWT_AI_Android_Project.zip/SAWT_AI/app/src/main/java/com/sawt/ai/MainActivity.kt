package com.sawt.ai

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var messages: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var maleChip: TextView
    private lateinit var femaleChip: TextView
    private var selectedVoice = 0
    private var localArabicVoices: List<Voice> = emptyList()
    private var languageAvailable = false

    private val ink = Color.rgb(32, 33, 35)
    private val muted = Color.rgb(112, 117, 124)
    private val green = Color.rgb(16, 163, 127)
    private val page = Color.rgb(247, 247, 248)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        tts = TextToSpeech(this, this)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(page)
        }

        // ChatGPT-inspired clean header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(12))
            setBackgroundColor(Color.WHITE)
        }
        val logo = TextView(this).apply {
            text = "ص"
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(green, 100)
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(42), dp(42)))
        val headerText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(11), 0, 0, 0)
        }
        headerText.addView(TextView(this).apply {
            text = "SAWT AI"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
        })
        headerText.addView(TextView(this).apply {
            text = "محوّل النصوص إلى صوت عربي"
            textSize = 12f
            setTextColor(muted)
        })
        header.addView(headerText, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(TextView(this).apply {
            text = "●"
            textSize = 12f
            setTextColor(green)
            contentDescription = "التطبيق جاهز"
        })
        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        val line = View(this).apply { setBackgroundColor(Color.rgb(232, 232, 235)) }
        root.addView(line, LinearLayout.LayoutParams(-1, dp(1)))

        scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
        }
        messages = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(22), dp(16), dp(20))
        }
        scroll.addView(messages, ScrollView.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        addAssistantMessage("مرحباً بك في SAWT AI 👋\n\nاكتب أي نص عربي، واختر الصوت، ثم اضغط «نطق النص». يمكنك إيقاف القراءة في أي لحظة من زر المقاطعة.")

        // Bottom composer, similar to a chat app
        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(10))
            setBackgroundColor(Color.WHITE)
        }

        input = EditText(this).apply {
            hint = "اكتب النص الذي تريد سماعه..."
            textSize = 16f
            setTextColor(ink)
            setHintTextColor(Color.rgb(145, 149, 156))
            gravity = Gravity.TOP or Gravity.RIGHT
            textDirection = View.TEXT_DIRECTION_RTL
            minLines = 2
            maxLines = 5
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(page, 18, Color.rgb(225, 226, 230), dp(1).toFloat())
            imeOptions = EditorInfo.IME_ACTION_NONE
        }
        composer.addView(input, LinearLayout.LayoutParams(-1, -2))

        val voiceRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(8))
        }
        voiceRow.addView(TextView(this).apply {
            text = "نوع الصوت"
            textSize = 13f
            setTextColor(muted)
        }, LinearLayout.LayoutParams(0, -2, 1f))

        maleChip = makeChip("رجالي", selected = true) { selectVoice(0) }
        femaleChip = makeChip("نسائي", selected = false) { selectVoice(1) }
        voiceRow.addView(maleChip, LinearLayout.LayoutParams(-2, dp(36)))
        voiceRow.addView(space(dp(8)), LinearLayout.LayoutParams(dp(8), 1))
        voiceRow.addView(femaleChip, LinearLayout.LayoutParams(-2, dp(36)))
        composer.addView(voiceRow)

        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val speakButton = TextView(this).apply {
            text = "▶  نطق النص"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(green, 16)
            setPadding(dp(18), dp(13), dp(18), dp(13))
            setOnClickListener { speakText() }
        }
        actionRow.addView(speakButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        actionRow.addView(space(dp(10)), LinearLayout.LayoutParams(dp(10), 1))
        val stopButton = TextView(this).apply {
            text = "■  مقاطعة الصوت"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(174, 54, 54))
            background = rounded(Color.rgb(255, 245, 245), 16, Color.rgb(242, 211, 211), dp(1).toFloat())
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener {
                tts?.stop()
                status.text = "تم إيقاف الصوت. يمكنك كتابة نص جديد أو تشغيله مرة أخرى."
            }
        }
        actionRow.addView(stopButton, LinearLayout.LayoutParams(0, dp(48), 1f))
        composer.addView(actionRow)

        status = TextView(this).apply {
            text = "جارٍ تجهيز الصوت العربي..."
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        }
        composer.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(composer, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
    }

    private fun makeChip(label: String, selected: Boolean, action: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(dp(16), 0, dp(16), 0)
            setOnClickListener { action() }
            setChipStyle(this, selected)
        }
    }

    private fun selectVoice(value: Int) {
        selectedVoice = value
        setChipStyle(maleChip, value == 0)
        setChipStyle(femaleChip, value == 1)
    }

    private fun setChipStyle(view: TextView, selected: Boolean) {
        view.setTextColor(if (selected) green else muted)
        view.background = rounded(
            if (selected) Color.rgb(232, 247, 242) else page,
            18,
            if (selected) Color.rgb(190, 229, 215) else Color.rgb(230, 230, 234),
            dp(1).toFloat()
        )
    }

    override fun onInit(result: Int) {
        if (result != TextToSpeech.SUCCESS) {
            status.text = "تعذر تشغيل محرك تحويل النص إلى صوت على هذا الجهاز."
            return
        }
        val engine = tts ?: return
        val languageResult = engine.setLanguage(Locale("ar"))
        languageAvailable = languageResult != TextToSpeech.LANG_MISSING_DATA &&
                languageResult != TextToSpeech.LANG_NOT_SUPPORTED
        localArabicVoices = engine.voices
            ?.filter { it.locale.language == "ar" && !it.isNetworkConnectionRequired }
            ?.sortedBy { it.name } ?: emptyList()

        status.text = when {
            !languageAvailable -> "لا توجد بيانات لغة عربية. نزّل صوتاً عربياً من إعدادات تحويل النص إلى كلام في الهاتف."
            localArabicVoices.isEmpty() -> "اللغة العربية متاحة، لكن لا يوجد صوت عربي محلي. نزّل بيانات صوت تعمل دون إنترنت."
            else -> "الصوت العربي المحلي جاهز للعمل دون إنترنت."
        }
    }

    private fun speakText() {
        val engine = tts
        val value = input.text.toString().trim()
        if (value.isEmpty()) {
            input.error = "اكتب نصاً أولاً"
            return
        }
        if (engine == null || !languageAvailable || localArabicVoices.isEmpty()) {
            status.text = "لا يوجد صوت عربي محلي جاهز. نزّل بيانات صوت عربية غير متصلة من إعدادات الهاتف ثم جرّب مجدداً."
            addAssistantMessage("لم أجد صوتاً عربياً يعمل دون إنترنت على هاتفك. افتح إعدادات تحويل النص إلى كلام، ونزّل بيانات صوت عربية محلية، ثم أعد المحاولة.")
            return
        }

        val preferred = if (selectedVoice == 0) {
            localArabicVoices.firstOrNull { it.name.contains("male", true) || it.name.contains("mascul", true) }
        } else {
            localArabicVoices.firstOrNull { it.name.contains("female", true) || it.name.contains("fem", true) }
        }
        val voice = preferred ?: localArabicVoices.first()
        engine.voice = voice
        addUserMessage(value)
        status.text = "يقرأ النص الآن بالصوت المحلي: ${voice.name}"
        engine.speak(value, TextToSpeech.QUEUE_FLUSH, null, "sawt-${System.currentTimeMillis()}")
    }

    private fun addUserMessage(value: String) {
        val bubble = TextView(this).apply {
            text = value
            textSize = 16f
            setTextColor(ink)
            gravity = Gravity.RIGHT
            textDirection = View.TEXT_DIRECTION_RTL
            setPadding(dp(15), dp(12), dp(15), dp(12))
            background = rounded(Color.rgb(232, 247, 242), 18)
        }
        val row = LinearLayout(this).apply {
            gravity = Gravity.START
            addView(bubble, LinearLayout.LayoutParams(-2, -2).apply { width = (resources.displayMetrics.widthPixels * 0.82f).toInt() })
        }
        messages.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addAssistantMessage(value: String) {
        val label = TextView(this).apply {
            text = "SAWT AI"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(green)
            setPadding(dp(3), 0, 0, dp(5))
        }
        val bubble = TextView(this).apply {
            text = value
            textSize = 15f
            setTextColor(ink)
            gravity = Gravity.RIGHT
            textDirection = View.TEXT_DIRECTION_RTL
            setPadding(dp(15), dp(13), dp(15), dp(13))
            background = rounded(Color.WHITE, 18, Color.rgb(234, 234, 237), dp(1).toFloat())
        }
        val group = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(label)
            addView(bubble)
        }
        messages.addView(group, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
    }

    private fun rounded(color: Int, radiusDp: Int, strokeColor: Int? = null, strokeWidth: Float = 0f) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
            if (strokeColor != null) setStroke(strokeWidth.toInt().coerceAtLeast(1), strokeColor)
        }

    private fun space(width: Int) = View(this)

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
